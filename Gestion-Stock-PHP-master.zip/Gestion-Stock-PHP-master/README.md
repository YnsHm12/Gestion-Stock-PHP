# Gestion-Stock-PHP
Gestion des produits, des clients, et des ventes avec code bar
